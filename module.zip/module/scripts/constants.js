const CONSTANTS = {
    MODULE_NAME: "Dynamic Viewer",
    MODULE_ID: "dynamicviewer",
    PATH: `modules/dynamicviewer/`,
    FLAG: "dynamicviewer",
	EXCLUSIONS: "Exclusions"
};
CONSTANTS.PATH = `modules/${CONSTANTS.MODULE_NAME}/`;
export default CONSTANTS;